set wildignore+=versions/*,cache/*
